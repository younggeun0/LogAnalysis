package kr.co.sist.log.run;

import kr.co.sist.log.view.Login;

public class LogAnalysisRun {

	public static void main(String[] args) {
		new Login(); 
	}
}